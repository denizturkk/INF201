#ifndef hashTable_h_
#define hashTable_h_

typedef struct person
{
    char name[30];
    char surname[30];
    int age;
    int height;
    int weight;

}person;

typedef struct bucket
{
 struct person* person;
 struct bucket* next;

}bucket;

int hash_Function(struct person person);

void add_to_table(struct bucket** hashTable, struct person personToAdd);

void delete_from_table(struct bucket** person ,struct person personToDelete);

int find_in_table(struct bucket** person, struct person personToFind);



#endif // hashTable_h_
