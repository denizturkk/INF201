#include "hashTable.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 10




void delete_from_table(struct bucket** hashTable ,struct person personToDelete)
{

    int findResult=find_in_table(hashTable,personToDelete);
    int index=hash_Function(personToDelete);
    //eleman yok
    if(findResult==0)
    {
        printf("there is not such a person in table!");
        printf("deleted code 0 \n");
    }
    //indekste ve nexti yok
    else if(findResult==1)
    {
        free(*(hashTable+index));
        *(hashTable+index)=NULL;
        printf("deleted code 1 \n");
    }

    //indekste  collision var son bucketta
    else if(findResult==-1)
    {
        struct bucket* tmp=*(hashTable+index);
        while(tmp->next->next!=NULL)
        {
            tmp=tmp->next;
        }

        free(tmp->next);
        tmp->next=NULL;

        printf("deleted code -1 \n");
    }

    //ilk bucketta va nexti var
    else if(findResult==2)
    {
       struct bucket* tmp=*(hashTable+index);
        *(hashTable+index)=tmp->next;
        free(tmp);
        printf("deleted code 2 \n");
    }

    //indekste findresultdan gelen s�radaki(degerdeki) bucketta ve o buckettan sonra
    //farkli bir bucket var
    else
    {
        struct bucket* tmp=*(hashTable+index);
        struct bucket* tmp2;
        for(int i=1;i<findResult-1 ;i++)
        {
            tmp=tmp->next;

        }
        tmp2=tmp->next;

        tmp->next=tmp2->next;
        free(tmp2);
        printf("deleted code index \n");

    }

}




int find_in_table(struct bucket** hashTable, struct person personToFind)
{
    int index;
    index=hash_Function(personToFind);
    printf("index to find %d ",index);
    int counter =1;
    int isBreaked=0;

    if(*(hashTable+index)==NULL )
    {
        printf("this record is not exist in the table! \n");
        return 0;
    }

    else if(*(hashTable+index)!=NULL)
    {
        struct bucket* tmp=*(hashTable+index);


            while(tmp!=NULL)
            {
                if(personToFind.age==tmp->person->age && personToFind.weight==tmp->person->weight && personToFind.height==tmp->person->height&&!strcmp(&personToFind.name,tmp->person->name)&& !strcmp(&personToFind.name,tmp->person->name))
                {
                    printf("this record is exist in %d.index and %d.bucket \n",index,counter);
                    isBreaked=1;
                    if(counter==1 && tmp->next==NULL)
                        return 1;

                    else if(counter==1 && tmp->next!=NULL)
                        return 2;

                    else if(counter>1 && tmp->next!=NULL)
                        return counter;
                    else if(counter>1 && tmp->next==NULL)
                        return -1;

                }

                counter++;
                tmp=tmp->next;
            }

        if(isBreaked==0)
        {
            printf("this record is not exist \n");
        }
            return 0;




    }

    //0 ise yok
    //1 eleman ilk bucketta ama nexti yok
    //2 eleman ilk bucketta ve nexti var
    //eleman�n bucket no'su geri d�ner eleman indexte ortada bir bucketta
    //-1 eleman indexte son bucketta
    return isBreaked;

}




void add_to_table(struct bucket** hashTable, struct person personToAdd)
{
    int index;
    index=hash_Function(personToAdd);
    printf("index to add %d ",index);
    struct bucket* tmp=*(hashTable+index);

    if(tmp==NULL)
    {
       *(hashTable+index)=(struct bucket*)malloc(sizeof(struct bucket));
        (*(hashTable+index))->next=NULL;

         struct person* tmpPersonPtr=malloc(sizeof(struct person));
        (*(hashTable+index))->person=tmpPersonPtr;

        tmpPersonPtr->age=personToAdd.age;
        tmpPersonPtr->height=personToAdd.height;
        tmpPersonPtr->weight=personToAdd.weight;
        strcpy(tmpPersonPtr->name,&personToAdd.name);
        strcpy(tmpPersonPtr->surname,&personToAdd.surname);


    }

    else if(tmp!=NULL)
    {
        struct bucket *tmp2 =tmp;
        while(tmp2->next!=NULL)
        {
            tmp2=tmp2->next;
        }

        tmp2->next=(struct bucket*)malloc(sizeof(struct bucket));
        tmp2->next->next=NULL;
        tmp2=tmp2->next;
        tmp2->person=malloc(sizeof(struct person));
        tmp2->person->age=personToAdd.age;
        tmp2->person->height=personToAdd.height;
        tmp2->person->weight=personToAdd.weight;
        strcpy(tmp2->person->name,&personToAdd.name);
        strcpy(tmp2->person->surname,&personToAdd.surname);
    }
    printf("added \n");
}


int hash_Function(struct person person)
{
    int hash=17;
    char name[30];
    strcpy(&name,person.name);
    char surname[30];
    strcpy(&surname,person.surname);
    //printf("name %s %s \n",name,surname);
    int age=person.age;
    int height=person.height;
    int weight=person.weight;
    int i=0;
    while(name[i])
    {
        int c =name[i];
        hash=(hash+(c*37+11))%N;
        i++;
    }

        i=0;

    while(surname[i])
    {
        int c =surname[i];
        hash=(hash+(c*37+11))%N;
        i++;
    }

    hash=(hash+(37*age+11))%N;
    hash=(hash+(37*weight+11))%N;
    hash=(hash+(37*height+11))%N;
    return hash;
}
