#include <stdio.h>
#include "hashTable.h"
#define N 10
#include <string.h>
#include <stdlib.h>
int main()
{

    struct bucket** hashTable;
    struct person p1;
    struct person p2;
    struct person p3;
    struct person p4;
    struct person p5;
    struct person p6;

    p1.age=21;
    p1.height=185;
    p1.weight=81;
    strcpy(p1.name,"Deniz");
    strcpy(p1.surname,"Turk");

    p2.age=27;
    p2.height=180;
    p2.weight=81;
    strcpy(p2.name,"ahmet");
    strcpy(p2.surname,"arslan");

    p3.age=23;
    p3.height=169;
    p3.weight=81;
    strcpy(p3.name,"ali");
    strcpy(p3.surname,"kaptan");

    p4.age=21;
    p4.height=185;
    p4.weight=70;
    strcpy(p3.name,"ayse");
    strcpy(p3.surname,"hayriye");

    p5.age=23;
    p5.height=160;
    p5.weight=48;
    strcpy(p5.name,"merve");
    strcpy(p5.surname,"aslan");

    p6.age=10;
    p6.height=140;
    p6.weight=50;
    strcpy(p6.name,"mehmet");
    strcpy(p6.surname,"uzun");


    hashTable= malloc(sizeof(struct bucket*)*N);

    for(int i =0;i< N;i++)
    {
        *(hashTable+i)=NULL;
       // printf("%d \n",*(hashTable+i));

    }

        int c;

    printf("\n\n\n--------add to table tests---------- \n\n\n");
    add_to_table(hashTable,p1);
    add_to_table(hashTable,p2);
    add_to_table(hashTable,p3);
    add_to_table(hashTable,p4);
    add_to_table(hashTable,p5);
    add_to_table(hashTable,p6);


    printf("\n\n---------find in the table test-------- \n\n\n");
    find_in_table(hashTable,p1);
    find_in_table(hashTable,p2);
    find_in_table(hashTable,p3);
    find_in_table(hashTable,p4);
    find_in_table(hashTable,p5);
    find_in_table(hashTable,p6);

    printf("\n\n------delete from the table tests-------- \n");
    printf("deleted from bigger person number to smaller p. number to observe that \ndelete function works in all differant conditions \n\n\n");
    delete_from_table(hashTable,p6);
    delete_from_table(hashTable,p5);
    delete_from_table(hashTable,p4);
    delete_from_table(hashTable,p3);
    delete_from_table(hashTable,p2);
    delete_from_table(hashTable,p1);
    delete_from_table(hashTable,p6);


    return 0;
}
