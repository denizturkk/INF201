#include <stdio.h>
#include "tp08.h"
#define SIZE 70




int main()
{
    int distancefactor=30;

    struct Graph* Graph=createGraph(SIZE);
    struct Node* SensorData=readData("sensor_locations.txt");

    printSensorData(SensorData,SIZE);
    fillGraph(Graph,SensorData,distancefactor,SIZE);
    printf("\n\n**********GRAPH REPRESENTATION*************\n\n");
    printf("\n\n--------------WITH 30 METERS --------------\n\n");
    printGraph(Graph);
    printf("\n\n**********GRAPH REPRESENTATION*************\n\n");
    printf("\n\n-----------------FINISHED--------------\n\n");

    double** matrix1=createWeightedAdjMatrix(SensorData,distancefactor,SIZE);
    printf("\n\n**********MATRIX REPRESENTATION************\n\n");
    printAdjMatrix(matrix1,SensorData,SIZE,distancefactor);

    distancefactor=20;
    double** matrix2=createWeightedAdjMatrix(SensorData,distancefactor,SIZE);
    printAdjMatrix(matrix1,SensorData,SIZE,distancefactor);

    distancefactor=10;
    double** matrix3=createWeightedAdjMatrix(SensorData,distancefactor,SIZE);
    printAdjMatrix(matrix3,SensorData,SIZE,distancefactor);

    distancefactor=5;
    double** matrix4=createWeightedAdjMatrix(SensorData,distancefactor,SIZE);
    printAdjMatrix(matrix4,SensorData,SIZE,distancefactor);

    distancefactor=2;
    double** matrix5=createWeightedAdjMatrix(SensorData,distancefactor,SIZE);
    printAdjMatrix(matrix5,SensorData,SIZE,distancefactor);

    return 0;
}
