#include "tp08.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define SIZE 70




struct Graph* createGraph(int V)
{
    struct Graph* graphHead=(struct Graph*)malloc(sizeof(struct Graph));

    graphHead->vertexNumber=V;

    //to create array of  adjlist(graph)
    struct adjList* tmp=(struct adjList*)malloc(sizeof(struct adjList)*V);

    //initialize the adj lists with NULL
    for(int i=0 ;i<V;i++)
    {
        (tmp+i)->head=NULL;
    }

    //writing graph address into  graph pointer variable of the graph struct which point the graph ;
    graphHead->arrayOfLists=tmp;

    return graphHead;

}

void addEdge(struct Graph* graph,struct AdjListNode anAdjListNode,int dest)
{
   struct adjList* tmp=graph->arrayOfLists;
   struct AdjListNode* tmp2;

    if((tmp+dest)->head==NULL)
    {
        (tmp+dest)->head=newAdjListNode(anAdjListNode);

    }
    else
    {
        tmp2=(tmp+dest)->head;

        while(tmp2->Next!=NULL)
        {
            tmp2=tmp2->Next;
        }

        tmp2->Next=newAdjListNode(anAdjListNode);

    }
}

struct AdjListNode* newAdjListNode(struct AdjListNode anAdjListNode)
{
    struct AdjListNode* aNode=(struct AdjListNode*)malloc(sizeof(struct AdjListNode));

    aNode->id =anAdjListNode.id;
    aNode->x =anAdjListNode.x;
    aNode->y =anAdjListNode.y;
    aNode->z =anAdjListNode.z;
    aNode->Next = NULL;
    return aNode;

}

struct Node* readData(char* nameOfFile)
{
    FILE* fptr = fopen(nameOfFile,"r");
    if(fptr==NULL)
    {
         printf("file cannot be opened! \n");
         return;
    }
    struct Node* SensorData= (struct Node*)malloc(sizeof(struct Node)*SIZE);

    int idd;
    double xaxe;
    double yaxe;
    double zaxe;

   for(int i=0;i<SIZE;i++)
   {
        fscanf(fptr,"%d,%lf,%lf,%lf",&idd,&xaxe,&yaxe,&zaxe);
        SensorData[i].id=idd;
        SensorData[i].x=xaxe;
        SensorData[i].y=yaxe;
        SensorData[i].z=zaxe;
   }
    fclose(fptr);
    return SensorData;
};


void printSensorData(struct Node* SensorData,int size)
{
    for(int i=0;i<size;i++)
    {
         printf("%d id:%d , x:%lf , y:%lf , z:%lf\n",i,SensorData[i].id,SensorData[i].x,SensorData[i].y,SensorData[i].z);
    }

}

double distanceCalculater(struct Node* sensorData,int first,int second)
{
    double x;
    double y;
    double z;
    x=sensorData[first].x-sensorData[second].x;
    x=pow(x,2);

    y=sensorData[first].y-sensorData[second].y;
    y=pow(y,2);

    z=sensorData[first].z - sensorData[second].z;
    z=pow(z,2);

    return sqrt(x+y+z);
}




void fillGraph(struct Graph* Graph,struct Node* sensorData,int distanceFactor,int size)
{
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            if(distanceCalculater(sensorData,i,j)<distanceFactor &&distanceCalculater(sensorData,i,j)!=0)
            {
               // printf("%d %d\n",j,i);
                struct AdjListNode adjListNode;
                adjListNode.id=sensorData[j].id;
                adjListNode.x=sensorData[j].x;
                adjListNode.y=sensorData[j].y;
                adjListNode.z=sensorData[j].z;
                adjListNode.Next=NULL;
                addEdge(Graph,adjListNode,i);

            }
        }

    }

}

void printGraph(struct Graph* Graph)
{
    struct AdjListNode* tmp;
    for(int i =0;i<SIZE; i++)
    {
        tmp=Graph->arrayOfLists[i].head;
        while(tmp!=NULL)
        {
           printf("%d.Sensor adjacent id:%d\n",i,tmp->id );
           tmp=tmp->Next;

        }

    }
}

double** createWeightedAdjMatrix(struct Node* sensorData,int distanceFactor,int size)
{
    double** matrix=(double*)malloc(sizeof(double*)*SIZE);
    for(int i=0;i<SIZE;i++)
    {
       matrix[i]=malloc(sizeof(double)*SIZE);
    }

     for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            if(distanceCalculater(sensorData,i,j)>distanceFactor)
               *(*(matrix+i)+j)=0;
            else
            *(*(matrix+i)+j)=distanceCalculater(sensorData,i,j);
        }
    }
 return matrix;
}


void printAdjMatrix(double** matrix,struct Node* sensorData,int size,int distanceFactor)
{
    int m=0;
    for(int i=0;i<size;i++)
    {
        printf("cap:%dm. id%d(x:%.2f y:%.2f z%.2f) distance %.3f neighboors:(",distanceFactor,sensorData[i].id,sensorData[i].x ,sensorData[i].y,sensorData[i].z,distanceCalculater(sensorData,0,i));
        for(int j=0;j<size;j++)
        {
            if(matrix[i][j]>0)
            {
                m++;
                printf("%d,",j);
            }
        }
        if(m==0)
            printf("node isole");
       else
       printf("number of neighboors %d",m);

        printf(")\n\n");
        m=0;
    }
printf("\n\n");

}

