#ifndef tp08_h_
#define tp08_h_

typedef struct Node
{
 int id;
 double  x;
 double y;
 double z;
}Node;


typedef struct AdjListNode
{
 int id;
 double x;
 double y;
 double z;
 struct AdjListNode* Next;

}AdjListNode;

typedef struct adjList
{
   struct AdjListNode* head;

}AdjList;

typedef struct Graph
{
    struct adjList* arrayOfLists;
    int vertexNumber;

}Graph;


struct AdjListNode* newAdjListNode(struct AdjListNode);
struct Graph* createGraph(int V);
void addEdge(struct Graph* graph,struct AdjListNode Node,int dest);
struct Node* readData(char* fileName);
void printSensorData(struct Node* SensorData,int size);
void fillGraph(struct Graph* Graph,struct Node* sensorData,int distanceFactor,int size);
double distanceCalculater(struct Node* sensorData,int first,int second);
void printGraph(struct Graph* Graph);
double** createWeightedAdjMatrix(struct Node* sensorData,int distanceFactor,int size);
void printAdjMatrix(double** matrix,struct Node* sensorData,int size,int distanceFactor);
#endif // tp08_h_
