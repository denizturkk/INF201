#ifndef linkedListPriority_h_
#define linkedListPriority_h

typedef struct record
{
    int data;
    int priority;

}record;

typedef struct node
{
    int data;
    int priority;
    struct node* next;
    struct node* prev;

}node;


void insertItem(struct node** Head,struct record item);
struct record getHighestPriority(struct node** Head);
void deleteHighestPriority(struct node** Head);
void changePriority(struct node** Head,struct record record,int p);
void removeItem(struct node** Head,struct record item);
void printQueue(struct node* Head);


#endif // linkedListPriority_h_
