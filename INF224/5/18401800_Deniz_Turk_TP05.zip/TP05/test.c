#include <stdio.h>
#include "linkedListPriority.h"
#include "heapPriority.h"


int main()
{

struct heapPriority* pqueue=NULL;

initializeHeap(&pqueue);
printf("---------TEST OF HEAP PQ----------\n");
insertToHeap(pqueue,7);
insertToHeap(pqueue,1);
insertToHeap(pqueue,9);
insertToHeap(pqueue,35);
insertToHeap(pqueue,4);
insertToHeap(pqueue,10);
insertToHeap(pqueue,13);
insertToHeap(pqueue,2);
insertToHeap(pqueue,20);
insertToHeap(pqueue,40);

printHeap(pqueue);

for(int i=0;i<10;i++)
{
    deleteFromHeap(pqueue);
    printHeap(pqueue);
    printf("\n");

}

insertToHeap(pqueue,7);
insertToHeap(pqueue,1);
insertToHeap(pqueue,9);
insertToHeap(pqueue,35);
insertToHeap(pqueue,4);
insertToHeap(pqueue,10);
insertToHeap(pqueue,13);
insertToHeap(pqueue,2);
insertToHeap(pqueue,20);
insertToHeap(pqueue,40);

printHeap(pqueue);

printf("---------TEST OF LINKED LIST PQ----------\n");


    struct node* Head=NULL;
    struct record aNode;
    struct record bNode;
    struct record cNode;
    struct record dNode;
    struct record eNode;
    struct record fNode;
    struct record gNode;

    aNode.data=5;
    aNode.priority=1;

    bNode.priority=3;
    bNode.data=10;

    cNode.priority=2;
    cNode.data=15;

    dNode.priority=1;
    dNode.data=25;

    eNode.priority=1;
    eNode.data=56;

    fNode.priority=1;
    fNode.data=78;

    gNode.priority=1;
    gNode.data=56;


    insertItem(&Head,aNode);
    insertItem(&Head,bNode);
    insertItem(&Head,cNode);
    insertItem(&Head,dNode);
    insertItem(&Head,eNode);
    insertItem(&Head,fNode);
    insertItem(&Head,gNode);
    printf("\n items inserted \n");

    printQueue(Head);

    changePriority(&Head,aNode,3);
    changePriority(&Head,cNode,2);
    changePriority(&Head,dNode,6);
    changePriority(&Head,fNode,1);
    changePriority(&Head,gNode,4);
      printf("\n prioritys changed \n");

    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
    deleteHighestPriority(&Head);
    printQueue(Head);
     printf("\n items deleted \n");

    insertItem(&Head,aNode);
    insertItem(&Head,bNode);
    insertItem(&Head,cNode);
    insertItem(&Head,dNode);
     printf("\n items inserted \n");

     printQueue(Head);
     removeItem(&Head,aNode);
     removeItem(&Head,cNode);
     removeItem(&Head,bNode);

    printf("\n3items removed\n");

     printQueue(Head);

    gNode=getHighestPriority(&Head);

    printf("all functions have been tested");



  return 0;
}
