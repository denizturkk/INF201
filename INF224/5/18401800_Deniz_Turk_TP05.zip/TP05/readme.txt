linked list ile olan pq'da dusuk numara yuksek oncelik verdim
