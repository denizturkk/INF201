#ifndef  heapPriority_h_
#define heapPriority_h_

typedef struct heapPriority
{
  int sizeOfPriority;
  int capacity;
  int* mHeap;
}heapPriority;

void initializeHeap(struct heapPriority** heapPriority);
void destroyHeap(struct heapPriority* heapPriority);
void insertToHeap(struct heapPriority* heapPriority,int p);
int isEmpty(struct heapPriority* heapPriority);
void printHeap(struct heapPriority* heapPriority);
void deleteFromHeap(struct heapPriority* heapPriority);


#endif // heapPriority_h_

