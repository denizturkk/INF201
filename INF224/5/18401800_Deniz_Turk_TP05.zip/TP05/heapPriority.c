#include <stdio.h>
#include <stdlib.h>
#include "heapPriority.h"

void initializeHeap(struct heapPriority** heapPriority)
{
    int capacity =20;

    *heapPriority=(struct heapPriority*)malloc(sizeof(struct heapPriority));

    (*heapPriority)->capacity=capacity;
    (*heapPriority)->sizeOfPriority=0;

    (*heapPriority)->mHeap=(int*)malloc(sizeof(int)*capacity);

}

void destroyHeap(struct heapPriority* heapPriority)
{
  free(heapPriority->mHeap);
  free(heapPriority);
}

int isEmpty(struct heapPriority* heapPriority)
{
    if(heapPriority->sizeOfPriority < heapPriority->capacity )
        return 1;
    else
        return 0;
}


void insertToHeap(struct heapPriority* heapPriority,int p)
{
    if(isEmpty(heapPriority))
    {
        heapPriority->mHeap[heapPriority->sizeOfPriority]=p;
        heapPriority->sizeOfPriority++;

        int childIndex=heapPriority->sizeOfPriority-1;
        int parentIndex=(childIndex-1)/2;
        int tmp;

        while(parentIndex>=0&& heapPriority->mHeap[childIndex] > heapPriority->mHeap[parentIndex])
        {
            tmp=heapPriority->mHeap[childIndex];
            heapPriority->mHeap[childIndex]=heapPriority->mHeap[parentIndex];
            heapPriority->mHeap[parentIndex]=tmp;
            childIndex=parentIndex;
            parentIndex=(childIndex-1)/2;
        }
    }
    else
    {
      printf("heap priority queue is full! \n");

    }

}

void deleteFromHeap(struct heapPriority* heapPriority)
{
    if(heapPriority->sizeOfPriority!=0)
    {
         heapPriority->sizeOfPriority--;
    }
    else
        printf("there is no record to be deleted! \n ");

    heapPriority->mHeap[0]=heapPriority->mHeap[heapPriority->sizeOfPriority];



    int parent=0;
    int biggest;
    int lchild=1;
    int rchild=2;


    while(lchild < heapPriority->sizeOfPriority )
    {
        lchild=2*parent+1;
        rchild=2*parent+2;
        biggest=parent;

        if(lchild < heapPriority->sizeOfPriority && heapPriority->mHeap[lchild]>heapPriority->mHeap[biggest])
        {
            biggest=lchild;
        }

        if(rchild < heapPriority->sizeOfPriority && heapPriority->mHeap[rchild]>heapPriority->mHeap[biggest])
        {
            biggest=rchild;
        }

        if(biggest!=parent)
        {
            int tmp=heapPriority->mHeap[biggest];
            heapPriority->mHeap[biggest]=heapPriority->mHeap[parent];
             heapPriority->mHeap[parent]=tmp;
            parent=biggest;
        }

        else
            break;


    }



}

void printHeap(struct heapPriority* heapPriority)
{
    for(int i=0 ;i<heapPriority->sizeOfPriority;i++)
    {
        printf("%d : %d \n",i+1,heapPriority->mHeap[i]);
    }

    printf("\n");
}

