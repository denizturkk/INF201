#include "linkedListPriority.h"
#include <stdlib.h>
#include <stdio.h>


void insertItem(struct node** Head,struct record item)
{

    // if there is any item in the pqueue
    if(*Head==NULL)
    {
        *Head=(struct node*)malloc(sizeof(struct node));
        (*Head)->data=item.data;
        (*Head)->priority=item.priority;
        (*Head)->prev=NULL;
        (*Head)->next=NULL;
    }

    else
    {
        //if there is more than  a node
        struct node* tmp;
        tmp=*Head;

        while(tmp->next!=NULL && item.priority>=tmp->priority)
        {
            tmp=tmp->next;
        }

        //0-0
        //eklenecek eleman daha oncelikli ve next null ise
        //ya sonday�z ya da tek eleman var
        if(tmp->next==NULL && item.priority < tmp->priority)
        {
            //if there is only 1 elements and element to insert have higher priority
            if(tmp->prev==NULL)
            {
                   (*Head)->prev=(struct node*)malloc(sizeof(struct node));
                   (*Head)->prev->next=(*Head);
                   (*Head)=(*Head)->prev;
                   (*Head)->prev==NULL;
                    (*Head)->data=item.data;
                    (*Head)->priority=item.priority;
            }
            //if we are at the end of the list and element to insert have higher priority
            else
            {
                struct node* tmp2;
                tmp2=(struct node*)malloc(sizeof(struct node));

                tmp2->data=item.data;
                tmp2->priority=item.priority;
                tmp2->next=tmp;
                tmp2->prev=tmp->prev;
                tmp->prev=tmp2;
                tmp2->prev->next=tmp2;
            }
        }

        //0-1
        //nexti null ise ise item prioritysi  daha buyuk ise
        else if(tmp->next==NULL && item.priority>=tmp->priority)
        {
            struct node* tmp3;
            tmp3=(struct node*)malloc(sizeof(struct node));
            tmp->next=tmp3;
            tmp3->prev=tmp;
            tmp3->next=NULL;
            tmp3->data=item.data;
            tmp3->priority=item.priority;
        }
        //1-0
        //nexti null degil ise
        else if(tmp->next!=NULL && item.priority<tmp->priority)
        {
            struct node* tmp4 =(struct node*)malloc(sizeof(struct node));
            tmp4->data=item.data;
            tmp4->priority=item.priority;

            tmp4->next=tmp;
            tmp4->prev=tmp->prev;
            tmp->prev=tmp4;
            tmp4->prev->next=tmp4;
        }
    }
}

void deleteHighestPriority(struct node** Head)
{
    if((*Head)->next!=NULL)
    {
        (*Head)=(*Head)->next;
        free((*Head)->prev);
        (*Head)->prev=NULL;
    }
    else if((*Head)->next==NULL)
    {
        free((*Head));
        (*Head)=NULL;
    }
}

struct record getHighestPriority(struct node** Head)
{
    struct record tmp;

    tmp.data=(*Head)->data;
    tmp.priority=(*Head)->priority;

    return tmp;
}

void printQueue(struct node* Head)
{
    struct node* tmp=Head;
    while(tmp!=NULL)
    {
        printf("priority :%d \tdata: %d \n",tmp->priority,tmp->data);
        tmp=tmp->next;
    }
    printf("\n\n");
}


void changePriority(struct node** Head,struct record recordToChange, int  p)
{
    removeItem(Head,recordToChange);
    recordToChange.priority=p;
    insertItem(Head,recordToChange);

}

void removeItem(struct node** Head,struct record item)
{

    struct node* tmp= *Head;
    while(tmp->data!=item.data && tmp->data!=item.priority && tmp!=NULL)
    {

        tmp=tmp->next;
    }

    //first element should be delete and there is more than a node
    if(tmp->prev==NULL &&  tmp->next!=NULL)
    {
        (*Head)=(*Head)->next;
         free((*Head)->prev);
        (*Head)->prev=NULL;
    }

    //if there is only 1 element
    else if(tmp->prev==NULL && tmp->next==NULL)
    {
            free(*Head);
            *Head=NULL;
    }
    //last element should be delete there is more than a node
    else if(tmp->next==NULL && tmp->prev!=NULL )
    {
        tmp->prev->next=NULL;
        free(tmp);
    }
    //in the middle
    else if(tmp->prev!=NULL && tmp->next!=NULL)
    {
            tmp->prev->next=tmp->next;
            tmp->next->prev=tmp->prev;
            free(tmp);
    }

}

