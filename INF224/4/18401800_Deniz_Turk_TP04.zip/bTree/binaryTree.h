#ifndef binaryTree_h_
#define binaryTree_h_

typedef struct node
{
    struct node* left;
    struct node* right;
    int data;

}node;

struct Node* createNode(int data);
struct node* insertNode(struct node* root,int data);
struct node* findMin(struct node* root);
struct node* findMax(struct node* root);
struct node* deleteNode(struct node* root,int data);
void inOrder(struct node* root);
void preOrder(struct node* root);
void postOrder(struct node* root);
struct node* search(struct node* root,int key);

#endif // binaryTree_h_

