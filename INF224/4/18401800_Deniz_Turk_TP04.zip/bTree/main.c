#include <stdlib.h>
#include <stdio.h>
#include "binaryTree.h"

int main()
{
    struct node* root;
    root=NULL;


    root=insertNode(root,30);
    root=insertNode(root,5);
    root=insertNode(root,10);
    root=insertNode(root,15);
    root=insertNode(root,20);
    root=insertNode(root,25);
    root=insertNode(root,35);
    root=insertNode(root,40);
    root=insertNode(root,45);
    root=insertNode(root,50);

    int choice=9;
    int data;
    struct node* tmp;
    while(choice!=10)
    {
        printf("\n\nplease make a choice\n\n");
        printf("1:insert a new node.\n");
        printf("2:find max value in tree.\n");
        printf("3:find min value in tree.\n");
        printf("4:delete a node.\n");
        printf("5:sort tree by pre-order.\n");
        printf("6:sort tree by in-order.\n");
        printf("7:sort tree by post-order.\n");
        printf("8:sort tree by level-order.\n");
        printf("9:search a number if its exists\n");
        printf("10:exit \n");

        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                printf("Enter a number to be inserted \n");
                scanf("%d",&data);
                root = insertNode(root,data);
                printf("%d inserted\n",data);
                break;

            case 2:
                    data = findMax(root);
                    printf("Max value is \t\t %d\n",data);
                break;

            case 3:
                data=findMin(root);
                printf("Min value is \t\t %d\n",data);

                break;

            case 4:
                printf("Enter the number to be deleted \n");
                scanf("%d",&data);
               deleteNode(root,data);
               printf("deleted \n");

                break;

            case 5:
                preOrder(root);


                break;

            case 6:
                inOrder(root);
                break;

            case 7:
                postOrder(root);
                break;

            case 8:
                    //levelOrder(root)
                printf("kodlanacak \n");
                break;

            case 9:
                printf("Enter the number to be searched \n");
                scanf("%d",&data);
                tmp=search(root,data);

                break;

            case 10:
                exit(1);
                choice=10;
                break;

                default:
                    printf("this is not a valid operation \n");

              break;
        }

    }


    return 0;
}
