#include <stdio.h>
#include <stdlib.h>
#include "binaryTree.h"

struct Node* createNode(int data)
{
    struct node* tmp=(struct node*)malloc(sizeof(struct node));
    tmp->left=NULL;
    tmp->right=NULL;
    tmp->data=data;

}

struct node* insertNode(struct node* root,int data)
{
    if(root==NULL)
    root=createNode(data);

    else if(root!=NULL&& root->data>=data)
    root->left=insertNode(root->left,data);

    else if(root!=NULL&& root->data<data)
    root->right=insertNode(root->right,data);

    return root;
}


struct node* findMin(struct node* root)
{

    struct node* tmp=root;

    if(root==NULL)
    {
        printf("there is no tree or node \n");
    }

    else
    {
        while(tmp->left!=NULL)
        {
           tmp=tmp->left;
        }

    }
    return tmp->data;
}

struct node* findMax(struct node* root)
{
    struct node* tmp=root;

    if(root==NULL)
    {
        printf("tree is no tree \n");
    }
    else
    {
        while(tmp->right!=NULL)
        {
           tmp=tmp->right;
        }

    }
    return tmp->data;

}

struct node* deleteNode(struct node* root,int data)
{

     // 0-tree is empty
    if(root==NULL)
    {
          printf("there is no tree \n");
          return root;
    }
    //data to be searched is smaller than current
    else if(root->data>data)
    {
        root->left=deleteNode(root->left,data);
    }

    //data to be searched is bigger than current
    else if(root->data<data)
    {
        root->right=deleteNode(root->right,data);
    }

    //data to be deleted
    else
    {    // 1- if  no child

         if(root->left==NULL && root->right==NULL)
        {
            free(root);
            //avoid dangling pointer
            root=NULL;
            return root;
        }
        //if one child left
        else if(root->left==NULL)
        {
                struct node *tmp=root;
                root=root->right;
                free(tmp);
        }
        //if 1 child right
        else if(root->right==NULL)
        {
            struct node* tmp=root;
            root=root->left;
            free(tmp);
        }
        //if 2 children
        else
        {
            struct node* tmp=findMin(root->right);
            root->data = tmp->data;
            root->right=deleteNode(root->right,tmp->data);
        }
    }
     return root;
}


void inOrder(struct node* root)
{
    if(root==NULL)
    {
        return;
    }

    inOrder(root->left);
    printf("%d \n",root->data);
    inOrder(root->right);
}

void preOrder(struct node* root)
{
    if(root==NULL)
    {
      return;
    }
     printf("%d\n",root->data);
     preOrder(root->left);
     preOrder(root->right);
}

void postOrder(struct node* root)
{
    if(root==NULL)
    {
        return;
    }

    postOrder(root->left);
    postOrder(root->right);
    printf("%d \n",root->data);
}

void levelOrder(struct node* root)
{





}

struct node* search(struct node* root,int key)
{
    if(root == NULL)
    {
        printf("%d is not exist in the Btree\n",key);
        return root;
    }

    if(root->data!=key)
    {
        if(root->data < key)
        {
            return search(root->right,key);
        }

        else
        {
             return search(root->left,key);
        }

    }

    printf("%d is exist in Btree\n",key);
    return root;

}
