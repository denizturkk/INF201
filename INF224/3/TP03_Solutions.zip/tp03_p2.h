

#ifndef __STACK_LINKED_LIST_H__
#define __STACK_LINKED_LIST_H__

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define PUSH  1
#define POP  2
#define DISPLAY  3
#define EXIT   4

struct stack_node
{
    int data;
    struct stack_node *nextItem;
};

struct stack_node *createNode(int data);
void displayStack(struct stack_node *head);
struct stack_node *pushNode(struct stack_node *head, int data);
struct stack_node *popNode(struct stack_node **head);


#endif /* __SPLAY_TREE_H__ */
