#include <stdio.h>
#include "tp03_p4.h"
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include <stdbool.h>

int main(void)
{
    int state, userData;
    struct queue_node *head = NULL;
    bool cntnue = true;

    while (cntnue)
    {
        printf("%s","-----\n1)Enqueue an item\n2)Dequeue an item\n3)Display all items\n4)Exit\n"); // prints menu
        userData = 0;
        state = 0; // 
        printf("Chose one from above\n");
        scanf("%d", &state);
        getchar();

        switch (state)
        {
        case ENQUEUE:
            printf("Choose a number to enqueue\n");
            scanf("%d", &userData);
            getchar();
            printf("Queuing %d\n", userData);
            head = enqueueNode(head, userData);
            break;
        case DEQUEUE:
            printf("Getting the first element of queue\n");
            userData = dequeueNode(&head)->data;
            if (userData != INT_MIN)
            {
                printf("Item dequeued: %d\n", userData);
            }
            else
            {
                printf("Queue is empty\n");
            }
            break;
        case DISPLAY:
            printf("Printing the whole queue\n");
            displayQueue(head);
            break;
        case EXIT:
            printf("Goodbye\n");
            cntnue = false;
            break;
        default:
            break;
        }
    }
    return 0;
}