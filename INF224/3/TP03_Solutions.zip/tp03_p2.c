
#include "tp03_p2.h"

struct stack_node *createNode(int data)
{
    struct stack_node *node;

    node = (struct stack_node *) malloc(sizeof(struct stack_node));

    if (node == NULL)
    {
        printf("Could not created the node\n");
        return NULL;
    }

    node->nextItem = NULL;
    node->data = data;

    return node;
}

struct stack_node *pushNode(struct stack_node *head, int data)
{
    if (head == NULL)
    {
        head = (createNode(data));
        return head;
    }

    struct stack_node *newNode = createNode(data);
    newNode->nextItem = head;
    head = newNode;
    return head;

}

struct stack_node *popNode(struct stack_node **head)
{
    if (*head == NULL)
    {
        struct stack_node *emptyNode = createNode(INT_MIN);
        return emptyNode;
    }
    else
    {
        struct stack_node *poppedNode = *head;
        *head = (*head)->nextItem;
        return poppedNode;
    }

}

void displayStack(struct stack_node *node)
{
    if (node == NULL)
    {
        printf("Stack is empty\n");
        return;
    }
    do
    {
        if (node == NULL)
        {
            return;
        }
        printf("%d\n", node->data);
        node = node->nextItem;
    }while (node!= NULL);
    
}
