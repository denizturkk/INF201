#include "tp03_p1.h"
#include <limits.h>

void pushData(struct stack *array, int data)
{

    array->items[array->lastIndex] = data;
	array->lastIndex ++;

}

int popData(struct stack *array)
{
	if (array->lastIndex > 0)
	{
		int poppedData = array->items[array->lastIndex-1];
    	array->lastIndex --;
		return poppedData;
	}
	return INT_MIN;
}

void displayStack(struct stack array)
{
	if (array.lastIndex == 0)
	{
		printf("Stack is empty\n");
		return;
	}
	
    for (int i = array.lastIndex; i >= 1 ; i--)
	{
		printf("%d\n",array.items[i - 1]);
	}
	
    
}
