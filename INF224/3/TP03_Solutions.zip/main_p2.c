#include <stdio.h>
#include "tp03_p2.h"
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include <stdbool.h>

int main(void)
{
    int state, userData;
    struct stack_node *head = NULL;
    bool cntnue = true;

    while (cntnue)
    {
        printf("%s","-------\n1)Push an item\n2)Pop an item\n3)Display all items\n4)Exit\n"); // prints menu
        userData = 0;
        state = 0; // 
        printf("Chose one from above\n");
        scanf("%d", &state);
        getchar();

        switch (state)
        {
        case PUSH:
            printf("Choose a number to push\n");
            scanf("%d", &userData);
            getchar();
            printf("Pushing %d\n", userData);
            head = pushNode(head, userData);
            break;
        case POP:
            printf("Getting the top element of stack\n");
            userData = popNode(&head)->data;
            if (userData != INT_MIN)
            {
                printf("Item popped: %d\n", userData);
            }
            else
            {
                printf("Stack is empty\n");
            }
            
            break;
        case DISPLAY:
            printf("Printing the whole stack\n");
            displayStack(head);
            break;
        case EXIT:
            printf("Goodbye\n");
            cntnue = false;
            break;
        default:
            break;
        }
    }
    return 0;
}