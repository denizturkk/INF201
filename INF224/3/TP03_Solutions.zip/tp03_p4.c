
#include "tp03_p4.h"

struct queue_node *createNode(int data)
{
    struct queue_node *node;

    node = (struct queue_node *) malloc(sizeof(struct queue_node));

    if (node == NULL)
    {
        printf("Could not created the node\n");
        return NULL;
    }

    node->nextItem = NULL;
    node->data = data;

    return node;
}

struct queue_node *enqueueNode(struct queue_node *head, int data)
{
    if (head == NULL)
    {
        head = (createNode(data));
        return head;
    }

    struct queue_node *newNode = createNode(data);
    struct queue_node *headNode = head;
    while (head->nextItem != NULL)
    {
        head = head->nextItem;
    }
    head->nextItem = newNode;
    return headNode;

}

struct queue_node *dequeueNode(struct queue_node **head)
{
    if (*head == NULL)
    {
        struct queue_node *emptyNode = createNode(INT_MIN);
        return emptyNode;
    }
    else
    {
        struct queue_node *dequeuedNode = *head;
        *head = (*head)->nextItem;
        return dequeuedNode;
    }

}

void displayQueue(struct queue_node *node)
{
    if (node == NULL)
    {
        printf("Queue is empty\n");
        return;
    }
    do
    {
        if (node == NULL)
        {
            return;
        }
        printf("%d\n", node->data);
        node = node->nextItem;
    }while (node!= NULL);
    
}
