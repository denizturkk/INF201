#ifndef __QUEUE_LINKED_LIST_H__
#define __QUEUE_LINKED_LIST_H__

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define ENQUEUE  1
#define DEQUEUE  2
#define DISPLAY  3
#define EXIT   4

struct queue_node
{
    int data;
    struct queue_node *nextItem;
};

struct queue_node *createNode(int data);
void displayQueue(struct queue_node *head);
struct queue_node *enqueueNode(struct queue_node *head, int data);
struct queue_node *dequeueNode(struct queue_node **head);


#endif /* __QUEUE_LINKED_LIST_H__ */
