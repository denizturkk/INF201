
#ifndef __STACK_ARRAY_H__
#define __STACK_ARRAY_H__

#include <stdio.h>
#include <stdlib.h>

#define PUSH  1
#define POP  2
#define DISPLAY  3
#define EXIT   4

#define MAXVALUE 1024

struct stack
{
    int lastIndex;
    int items[MAXVALUE];
};

void displayStack(struct stack array);
void pushData(struct stack *array, int data);
int popData(struct stack *array);


#endif /* __STACK_ARRAY_H__ */
