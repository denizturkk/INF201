#include "tp03_p3.h"
#include <limits.h>

// implemented with circular array logic

void enqueueData(struct stack *array, int data)
{

	if (array->lastIndex < MAXVALUE && array->lastIndex >= array->firstIndex)
	{
		array->items[array->lastIndex] = data;
		array->lastIndex ++;
	}
	else if (array->lastIndex == MAXVALUE && array->firstIndex > 1)
	{
		array->items[0] = data;
		array->lastIndex = 1;
	}
	else if(array->lastIndex < array->firstIndex-1)
	{
		array->items[array->lastIndex] = data;
		array->lastIndex ++;
	}
	else
	{
		printf("Queue is nearly full, dequeue some items first\n");
	}
	
}

int dequeueData(struct stack *array)
{
	if (array->firstIndex < array->lastIndex)
	{
		int dequeuedData = array->items[array->firstIndex];
    	array->firstIndex++;
		return dequeuedData;
	}
	else if (array->firstIndex < MAXVALUE && array->firstIndex != array->lastIndex)
	{
		int dequeuedData = array->items[array->firstIndex];
    	array->firstIndex++;
		return dequeuedData;
	}
	else if (array->firstIndex == MAXVALUE && array->lastIndex != MAXVALUE)
	{
		int dequeuedData = array->items[0];
    	array->firstIndex = 1;
		return dequeuedData;
	}
	
	return INT_MIN;
}

void displayStack(struct stack array)
{
	if (array.firstIndex == array.lastIndex)
	{
		printf("Queue is empty\n");
	}
	else
	{
		if(array.lastIndex < array.firstIndex)
		{
			for (int i = array.firstIndex; i < MAXVALUE ; i++)
			{
				printf("%d\n",array.items[i]);
			}
			for (int i = 0; i <= array.lastIndex-1 ; i++)
			{
				printf("%d\n",array.items[i]);
			}

		}
		else
		{
			for (int i = array.firstIndex; i < array.lastIndex ; i++)
			{
				printf("%d\n",array.items[i]);
			}
		}
	}
	
	
    
}
