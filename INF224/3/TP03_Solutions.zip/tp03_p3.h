
#ifndef __QUEUE_ARRAY_H__
#define __QUEUE_ARRAY_H__

#include <stdio.h>
#include <stdlib.h>

#define ENQUEUE  1
#define DEQUEUE  2
#define DISPLAY  3
#define EXIT   4

#define MAXVALUE 128

struct stack
{
    int firstIndex;
    int lastIndex;
    int items[MAXVALUE];
};

void displayStack(struct stack array);
void enqueueData(struct stack *array, int data);
int dequeueData(struct stack *array);


#endif /* __QUEUE_ARRAY_H__ */
